#!/bin/bash

if [ $# -eq 1 ]; then

  for FILE in `cat $1`; do
    echo $FILE
    pbs=run_$FILE.pbs

    cp run.pbs $pbs

    echo -n "mpirun " >> $pbs
    echo -n "root4star -b -q -x 'Analysis_Macro.C(" >> $pbs
    echo -n '1000000000,"'$FILE'")'"'"  >> $pbs # number of events, file

    qsub $pbs
    mv $pbs script/
  done

else
  echo "usage: $0 filelist"
fi
